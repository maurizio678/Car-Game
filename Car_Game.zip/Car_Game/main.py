command = ""
started = False
stopped = False
fast = False
while True:
			command = input("> ")
			if command.lower() == "start":
					if started:
						print("Car is already started.")
					else:
						started = True
						print("Car started...")
			elif command.lower() == "brake":
				if stopped:
					print("Car is already stopped.")
				else:
						stopped = True
						print("Car stopped.")
			elif command.lower() == "help":
						print("""
						start - start car
						brake - stop car
						horn - beeps horn
						faster - car go zoom
						skid - uh oh
						help - see commands 
						""")
			elif command.lower() == "horn":
					print("beep beep")
			elif command.lower() == "faster":
				if fast:
					print("Car is at max speed")
				else:
					fast = True
					print("ZOOM")
			elif command.lower() == "skid":
					print("SKREEEEEEE")
			else:
					print("I don't understand. Type Help for commands")